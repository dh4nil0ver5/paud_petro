		<table class='table table-bordered'>
			<thead>
				<tr>
					<th>No</th>
					<th>Nama Lengkap</th>
					<th>Nama Panggilan</th>
					<th>Jenis Kelamin</th>
					<th>No. KK</th>
					<th>NIK</th>
					<th>Tanggal Lahir</th>
					<th>Kota Tempat Lahir</th>
					<th>Alamat Rumah</th>
					<th>Provinsi</th>
					<th>Kabupaten/Kotamadya</th>
					<th>Kecamatan</th>
					<th>Desa/Kelurahan</th>
					<th>Agama</th>
					<th>Kewarganegaraan</th>
					<th>Anak ke -</th>
					<th>Jumlah Saudara</th>
				</tr>
			</thead>
			<tbody>
				@php $i=1 @endphp
				@foreach($datas as $s)
				<tr>
					<td>{{ $i++ }}</td>
					<td>{{$s->nama_lengkap}}</td>
					<td>{{$s->nama_panggilan}}</td>
					<td>{{$s->jenis_kelamin}}</td>
					<td>{{$s->no_kk}}</td>
					<td>{{$s->nik}}</td>
					<td>{{$s->tanggal_lahir}}</td>
					<td>{{$s->kota_kelahiran}}</td>
					<td>{{$s->alamat_rumah}}</td>
					<td>{{$s->kelurahan}}</td>
					<td>{{$s->kecamatan}}</td>
					<td>{{$s->kabupaten}}</td>
					<td>{{$s->provinsi}}</td>
					<td>{{$s->agama}}</td>
					<td>{{$s->kewarganegaraan}}</td>
					<td>{{$s->anak_ke}}</td>
					<td>{{$s->jumlah_saudara}}</td>
				</tr>
				@endforeach
			</tbody>
		</table>