@extends('layouts.cpanel')

@section('content')
<div class="container-fluid text-center">
    <h1 style="margin-top: 10%;">Selamat datang !</h1>
</div>
@endsection
