 
<?php $__env->startSection('content'); ?>
    <div class="card" style="margin-top: -5px;">
        <div class="card-header">
            <h3 class="card-title">
                <select name="" id="data_negara" class="form-control">
                    <option value="kosong">--Pilih--</option>
                </select>
            </h3> 
        </div>
        <div class="card-body" style="font-size: 12px;">  
            <div class="table-responsive" id="provinsi">
                <table id="dt_negara">
                    <thead>
                        <tr> 
                            <th>Dinas</th>
                            <th>BPS</th>
                            <th>Nama Provinsi</th>
                        </tr>
                    </thead> 
                    <tbody></tbody>
                </table>
            </div>
            <div class="table-responsive disable" id="kota"></div>
            <div class="table-responsive disable" id="kelurahan"></div>
        </div>
    </div> 
    <script> 
    var result_data="";
    $("#dt_negara").DataTable().destroy();
    $("#dt_negara").DataTable({
        processing: true,
        serverSide: false,
        aLengthMenu: [[5, 50, 75, -1], [5, 50, 75, "All"]],
        iDisplayLength: 5,
        bPaginate: true,
        bFilter: false,
        ajax: {
            url: "<?php echo url('get_provinsi'); ?>",
            type: "get",
            dataSrc: function (json) { 
            var return_data = new Array();
                return return_data;
            },
        },
        columns: [ 
            { data: 'NAMA_LENGKAP'}, 
            { data: 'NAMA_PANGGILAN'},
            { data: 'JENIS_KELAMIN'} 
        ]
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cpanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>