<?php $__env->startSection('content'); ?>
<div class="container-fluid text-center">
    <h1 style="margin-top: 10%;">Selamat datang !</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cpanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>